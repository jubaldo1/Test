        <footer>
           <img src="img/CSUMB Logo.png" alt="Picture of CSUMB Logo" />
            <hr>
            CST336 Internet Programming. 2017&copy; Connolly <br/>
            <strong> Disclaimer:</strong> The information in this webpage is fictitous. <br />
            It is used for academic purposes only.
        </footer>

    </body>
</html>

