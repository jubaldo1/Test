<?php
    include 'header.php';
?>
            
        <!-- add Carousel component -->
        <br /><br />
        <a class="btn btn-outline-primary" href="login.php" role="button">Login </a>

        <br /><br />
        <hr>
        
<?php
    include 'footer.php';
?>